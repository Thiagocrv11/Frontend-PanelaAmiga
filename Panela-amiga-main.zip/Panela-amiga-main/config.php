<?php

    $dbHost = 'Localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'formulario-panela-amiga';

    $conexao = new mysqli( $dbHost,$dbUsername,$dbPassword,$dbName );

?>